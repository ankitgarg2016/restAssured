package NonBDDStyle;

import org.hamcrest.Matchers;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification;

public class NonBDDStylePostRequest_Azure {

	public static void main(String[] args) {

		String userName = "subuadmin@m365x250754.onmicrosoft.com";
		String password ="MSiphone917";
		String scope= "https://graph.microsoft.com/.default";
		String client_secret ="7DH9j@FRQRLQk:hj65YPDUpGD@HOYiq?";
		String client_id ="3a7352fa-df64-4a70-b48b-201f40a463e6";
		String accessToken = getToken(userName, password, scope, client_secret, client_id);
		
		// Create a request specification 
		RequestSpecification request= RestAssured.given();
		
		//Adding URI
		request.baseUri("https://restful-booker.herokuapp.com/booking");
		
		// Calling GET method on URI. After hitting we get Response
		Response response = request.get();
		
		// Let's print response body.
		String resString = response.asString();
		System.out.println("Respnse Details : " + resString);
 
		/*
		 * To perform validation on response like status code or value, we need to get
		 * ValidatableResponse type of response using then() method of Response
		 * interface. ValidatableResponse is also an interface.
		 */
		ValidatableResponse valRes = response.then();
		// It will check if status code is 200
		valRes.statusCode(200);
		// It will check if status line is as expected
		valRes.statusLine("HTTP/1.1 200 OK");
	 }

	/**
	 * @param userName
	 * @param password
	 * @param scope
	 * @param client_secret
	 * @param client_id
	 */
	private static String getToken(String userName, String password, String scope, String client_secret,
			String client_id) {
		RequestSpecification request = RestAssured.given();
		request.baseUri("https://login.microsoftonline.com/7e6d8321-6782-496e-97e8-bfd4a4b682f3/oauth2/v2.0/token");
		request.contentType(ContentType.URLENC.withCharset("UTF-8"));
		request.formParam("grant_type", "password");
		request.formParam("client_id", client_id);
		request.formParam("client_secret", client_secret);
		request.formParam("scope", scope);
		request.formParam("password", password);
		request.formParam("userName", userName);
		
	
		Response response = request.post();

		System.out.println(response.asString());
		ValidatableResponse validatableResponse = response.then();
		validatableResponse.statusCode(200);

		String accessToken =validatableResponse.extract().jsonPath().get("access_token").toString();
		  
		System.out.println(accessToken);		
		  // Validate token field is null 
		// SInce response is one to one mapping so passing key name will give you value. 
		// Below method validates that value of token is not null. 
		  validatableResponse.body("access_token",Matchers.notNullValue());
		  return accessToken;
	}

}
